
#!/bin/bash
# Coded By Omar Salloum #
#     Date 2\10\2016    #
#########################
echo ""
read -p "$( tput setaf 10)>$(tput sgr0)$(tput bold)$( tput setaf 4) Do You Want To Lauch MSF Listening mod ?  ? [ $( tput setaf 10)y$(tput sgr0) $(tput bold)$( tput setaf 4)/$(tput sgr0) $(tput bold)$( tput setaf 10)n $(tput sgr0)$(tput bold)$( tput setaf 4)] $(tput sgr0)$(tput bold)" choice
case "$choice" in 
  y|Y ) bash data/handler.sh;;
  n|N ) clear & exit ;;
  * ) echo "invalid";;
esac
