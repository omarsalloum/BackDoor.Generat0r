#!/bin/bash
# Coded By Omar Salloum #
#     Date 2\10\2016    #
#########################
clear
sleep 0.1
echo "$(tput bold)$( tput setaf 10)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~$(tput sgr0)"

sleep 0.1
echo "$( tput setaf 10)~                                                          ~"
sleep 0.1
echo "~                    ######   ##    ##                     ~"
sleep 0.1 
echo "~                   ##    ##   ##  ##                      ~ "
sleep 0.1
echo "~                   ##          ####                       ~"
sleep 0.1
echo "~                    ######      ##                        ~"
sleep 0.1
echo "~                         ##     ##                        ~"
sleep 0.1
echo "~                   ##    ##     ##                        ~"
sleep 0.1
echo "~                    ######      ##                        ~ "
sleep 0.1
echo "$( tput setaf 10)~                                                          ~$(tput sgr0)"
sleep 0.1
echo "$( tput setaf 10)~ $(tput sgr0)                  © Syrian St0rm                         $( tput setaf 10)~$(tput sgr0)"
sleep 0.1
echo "$( tput setaf 10)~                                                          ~$(tput sgr0)"
sleep 0.1
echo "$(tput bold)$( tput setaf 10)~$(tput sgr0)                 $(tput bold)$( tput setaf 1)Backdoors Generator Tools                $(tput bold)$( tput setaf 10)~$(tput sgr0)"
sleep 0.1
echo "$( tput setaf 10)~                                                          ~$(tput sgr0)"
sleep 0.1
echo "$(tput bold)$( tput setaf 10)~$(tput sgr0)             Coded By :$(tput bold)$( tput setaf 4) Th3 Syrian St0rm                  $(tput bold)$( tput setaf 10)~$(tput sgr0)"  
sleep 0.1
echo "$(tput bold)$( tput setaf 10)~$(tput sgr0)               E-mail : $(tput bold)$( tput setaf 4)o90@live.se                       $( tput setaf 10)~$(tput sgr0)"
sleep 0.1
echo "$(tput bold)$( tput setaf 10)~$(tput sgr0)            Tested on : $(tput bold)$( tput setaf 4)Kali/Ubuntu/Parrot                $(tput bold)$( tput setaf 10)~$(tput sgr0)"
sleep 0.1
echo "$( tput setaf 10)~                                                          ~$(tput sgr0)"
echo "$(tput bold)$( tput setaf 10)~   The Coder Is Not Responsible For Any Harmfull Results  ~$(tput sgr0)"
sleep 0.1
echo "$(tput bold)$( tput setaf 10)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~$(tput sgr0)"
sleep 1
bash data/msfvenom.sh

